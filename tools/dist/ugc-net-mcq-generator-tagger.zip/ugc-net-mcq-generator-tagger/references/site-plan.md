# The set plan, age by age

Generated from `_data/mcqSpec.json`. **Status** says what exists on the site now. A planned set has a title and a scope but no
questions yet. "live, free" means its files are public; "live, login" means only logged-in students read them. Use the title as
`setName` and the scope to choose the set-local `topics`. The levels column is what the plan expects.

## `old-english` — Old English (450–1066)

Notes: `/notes/old-english/` (Old English — the full notes). `age` = `old-english`, `ageName` = `Old English`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | live, free | the age, its poems, manuscripts, prose and terms |
| 2 | Poetry and the verse line | easy + medium | live, free | Beowulf, the elegies, Cædmon, Cynewulf, the riddles |
| 3 | Prose and its writers | easy + medium | live, free | Alfred, the Anglo-Saxon Chronicle, Ælfric, Wulfstan, the law codes |
| 4 | Prose and its writers: Alfred, the Chronicle, Ælfric, Wulfstan, the law codes | easy + medium | live, login |  |
| 5 | Terms, dates and sources | medium | live, login | kenning, caesura, comitatus, wergild, futhorc, Danelaw, Danegeld |
| 6 | Criticism and scholarship | medium + hard | live, login | Ker, Chambers, Klaeber, the 1936 lecture, Whitelock, Magoun, Heaney |

Hub topics the plan uses: The ground to know (ground), Poetry and the verse line (poetry), Prose and its writers (prose), Manuscripts and survival (manuscripts), Terms, dates and sources (terms), Criticism and scholarship (criticism).

## `anglo-norman` — Anglo-Norman Period (1066–1340)

Notes: `/notes/middle-english/` (Middle English — the full notes). `age` = `anglo-norman`, `ageName` = `Anglo-Norman Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | live, free | the Conquest, the three languages, the chroniclers, the poems, the prose and the first plays |
| 2 | Poetry and romance | medium + hard | live, login | Layamon, Orm, The Owl and the Nightingale, Marie de France, King Horn, Havelok, Sir Orfeo |
| 3 | Chronicles, religious writing and early drama | medium + hard | planned | Geoffrey of Monmouth, Wace, Ancrene Wisse, Mannyng, Cursor Mundi, Le Mystère d'Adam |

Hub topics the plan uses: The age and its languages (ground), Poetry and romance (poetry), Chronicles and the Arthurian story (chronicles), Religious writing and early drama (religious), Terms, dates and sources (terms).

## `age-of-chaucer` — Age of Chaucer (1340–1400)

Notes: `/notes/middle-english/` (Middle English — the full notes). `age` = `age-of-chaucer`, `ageName` = `Age of Chaucer`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | live, free | the Black Death, the Peasants' Revolt, Chaucer, Langland, Gower, the Gawain poet and Wycliffe |
| 2 | Chaucer and his works | easy + medium | planned | The Book of the Duchess, The House of Fame, The Parliament of Fowls, Troilus and Criseyde, The Canterbury Tales |
| 3 | Langland, Gower and the Gawain poet | medium + hard | planned | Piers Plowman, Confessio Amantis, Vox Clamantis, Pearl, Sir Gawain and the Green Knight |
| 4 | Life and times, the Church and prose | medium + hard | planned | the Peasants' Revolt, the Hundred Years' War, Wycliffe and the Lollards, Julian of Norwich, Mandeville's Travels |

Hub topics the plan uses: The age and its events (ground), Chaucer and his works (chaucer), Langland, Gower and the Gawain poet (poets), The Church and prose (church), Terms, dates and sources (terms).

## `fifteenth-century` — Fifteenth Century (1400–1500)

Notes: `/notes/middle-english/` (Middle English — the full notes). `age` = `fifteenth-century`, `ageName` = `Fifteenth Century`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | live, free | Caxton, Malory, the mystery and morality plays, the Scottish Chaucerians, Lydgate, Hoccleve, Skelton and the Paston Letters |
| 2 | Prose, printing and letters | easy + medium | planned | Le Morte d'Arthur, Caxton's press at Westminster, the Paston Letters, The Book of Margery Kempe |
| 3 | Poetry: Lydgate, Hoccleve, the Scottish Chaucerians and Skelton | medium + hard | planned | Troy Book, Regement of Princes, The Testament of Cresseid, Lament for the Makaris and Skelton |
| 4 | Mystery and morality plays | medium + hard | planned | The Second Shepherds' Play, the Towneley cycle, The Castle of Perseverance, Mankind, Everyman |

Hub topics the plan uses: The age, printing and the Wars of the Roses (ground), Prose, printing and letters (prose), Poetry (poetry), Mystery and morality plays (drama), Terms, dates and sources (terms).

## `renaissance` — Renaissance Period (1500–1660)

Notes: `/notes/renaissance/` (Renaissance — the full notes). `age` = `renaissance`, `ageName` = `Renaissance Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | live, free | Spenser, Sidney, Marlowe, Shakespeare, Jonson, Donne, the Cavalier poets, Bacon and Milton |
| 2 | Drama from Kyd to Webster | easy + medium | planned | The Spanish Tragedy, Doctor Faustus, Hamlet, Volpone, The Duchess of Malfi |
| 3 | Poetry from Wyatt to Milton | medium + hard | planned | Wyatt, Surrey, Astrophil and Stella, The Faerie Queene, Donne, Herbert, Herrick, Lycidas |
| 4 | Prose and criticism | medium + hard | planned | Utopia, Euphues, The Defence of Poesy, Bacon's Essays, The Anatomy of Melancholy, the King James Bible |
| 5 | Terms, movements and criticism | medium + hard | planned | humanism, the sonnet, blank verse, the Spenserian stanza, euphuism, the University Wits, Tillyard, Eliot on the Metaphysical poets |

Hub topics the plan uses: The age, its ideas and its language (ground), Drama (drama), Poetry (poetry), Prose and criticism (prose), Terms, movements and criticism (terms).

## `early-tudor` — Early Tudor Period (1500–1558)

Notes: `/notes/renaissance/` (Renaissance — the full notes). `age` = `early-tudor`, `ageName` = `Early Tudor Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | live, free | More's Utopia, Skelton, Wyatt, Surrey, Tottel's Miscellany, Tyndale and Ascham |
| 2 | Poetry and the sonnet | medium + hard | planned | Wyatt, Surrey's English sonnets and blank-verse Aeneid, Tottel's Miscellany, Skelton's Philip Sparrow and Colin Clout |
| 3 | Prose, humanism and the Reformation | medium + hard | planned | More's Utopia and History of King Richard III, Tyndale's New Testament, Ascham's Toxophilus, Christian humanism |

Hub topics the plan uses: The age, humanism and the Reformation (ground), Poetry and the sonnet (poetry), Prose and the English Bible (prose), Terms, dates and sources (terms).

## `elizabethan` — Elizabethan Age (1558–1603)

Notes: `/notes/renaissance/` (Renaissance — the full notes). `age` = `elizabethan`, `ageName` = `Elizabethan Age`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | live, free | Spenser, Sidney, Marlowe, Kyd, the University Wits, Shakespeare, the playhouses and the critics |
| 2 | Spenser, Sidney and the sonnet | easy + medium | planned | The Shepheardes Calender, The Faerie Queene, Amoretti, Epithalamion, Astrophil and Stella, Arcadia, Delia |
| 3 | The University Wits and Elizabethan drama | medium + hard | planned | Kyd's The Spanish Tragedy, Marlowe's Tamburlaine and Doctor Faustus, Lyly, Peele, Greene, Nashe |
| 4 | Shakespeare and the playhouses | medium + hard | planned | Venus and Adonis, Romeo and Juliet, Julius Caesar, Hamlet, the playhouses and the companies |
| 5 | Prose and criticism | medium + hard | planned | Euphues, The Unfortunate Traveller, The Defence of Poesy, Puttenham's Arte, Hakluyt, Bacon's Essays |

Hub topics the plan uses: The age and its playhouses (ground), Spenser, Sidney and the sonnet (poetry), The University Wits and Shakespeare (drama), Prose and criticism (prose), Terms, dates and sources (terms).

## `jacobean` — Jacobean Age (1603–1625)

Notes: `/notes/jacobean-and-caroline-age/` (Jacobean and Caroline — the full notes). `age` = `jacobean`, `ageName` = `Jacobean Age`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | James I, the King James Bible, Shakespeare's later plays, Jonson, Webster, Middleton, Donne, Bacon and the court masques |
| 2 | Shakespeare's later plays and the Jacobean stage | easy + medium | planned | Othello, King Lear, Macbeth, The Winter's Tale, The Tempest, the First Folio |
| 3 | Jonson, Webster, Middleton and the court masque | medium + hard | planned | Volpone, The Alchemist, Bartholomew Fair, The White Devil, The Duchess of Malfi, The Changeling |
| 4 | Donne, Bacon and the prose of the age | medium + hard | planned | Donne's Songs and Sonnets and Holy Sonnets, Bacon's Essays, The Anatomy of Melancholy, the King James Bible |

Hub topics the plan uses: The age of James I (ground), Drama and the court masque (drama), Donne and the Metaphysical poets (poetry), Bacon, Burton and the King James Bible (prose), Terms, dates and sources (terms).

## `caroline` — Caroline Age (1625–1649)

Notes: `/notes/jacobean-and-caroline-age/` (Jacobean and Caroline — the full notes). `age` = `caroline`, `ageName` = `Caroline Age`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Charles I, the Civil War, the Cavalier poets, Herbert, Ford, Milton's early works and Browne |
| 2 | Cavalier and devotional poetry | medium + hard | planned | Herrick's Hesperides, Carew, Suckling, Lovelace, Herbert's The Temple, Crashaw's Steps to the Temple, Vaughan, Milton's Comus and Lycidas |
| 3 | Drama and prose | medium + hard | planned | Ford's 'Tis Pity She's a Whore and The Broken Heart, Massinger, Shirley's Hyde Park, Browne's Religio Medici, Hobbes |

Hub topics the plan uses: Charles I and the Civil War (ground), Cavalier and devotional poetry (poetry), Drama before the theatres closed (drama), Browne, Hobbes and prose (prose), Terms, dates and sources (terms).

## `commonwealth` — Commonwealth Period (1649–1660)

Notes: `/notes/jacobean-and-caroline-age/` (Jacobean and Caroline — the full notes). `age` = `commonwealth`, `ageName` = `Commonwealth Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | the Commonwealth and the Protectorate, Milton, Marvell, Hobbes, Browne, Walton, Vaughan, Cowley and the theatre ban |
| 2 | Poetry: Marvell, Vaughan, Cowley and Katherine Philips | medium + hard | planned | Marvell's 'Horatian Ode' and 'The Garden', Vaughan's Silex Scintillans, Cowley, Katherine Philips's Poems |
| 3 | Prose, ideas and the stage | medium + hard | planned | Hobbes's Leviathan, Browne's Urn Burial, Walton's The Compleat Angler, Milton's Eikonoklastes, Margaret Cavendish, Davenant's The Siege of Rhodes, the Diggers and Levellers |

Hub topics the plan uses: The Commonwealth and the theatre ban (ground), Poetry (poetry), Prose, ideas and the stage (prose), Terms, dates and sources (terms).

## `neoclassical` — Neoclassical Period (1660–1785)

Notes: `/notes/restoration-age/` (Restoration — the full notes). `age` = `neoclassical`, `ageName` = `Neoclassical Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | the Restoration stage, Dryden, Pope, Swift, Addison and Steele, Defoe, Richardson, Fielding, Sterne, Johnson, Gray and Goldsmith |
| 2 | Poetry: Dryden, Pope, Gray and Goldsmith | easy + medium | planned | Absalom and Achitophel, The Rape of the Lock, An Essay on Man, Elegy Written in a Country Churchyard, The Deserted Village |
| 3 | The stage: Restoration comedy to Sheridan | medium + hard | planned | The Country Wife, The Way of the World, The Beggar's Opera, She Stoops to Conquer, The School for Scandal |
| 4 | Prose and the rise of the novel | medium + hard | planned | The Spectator, Robinson Crusoe, Gulliver's Travels, Pamela, Tom Jones, Tristram Shandy, Johnson's Dictionary |
| 5 | Criticism, ideas and terms | medium + hard | planned | Dryden's Of Dramatic Poesie, Pope's An Essay on Criticism, Johnson's Preface to Shakespeare, neoclassicism, the heroic couplet, sensibility |

Hub topics the plan uses: The age and its ideas (ground), Poetry and satire (poetry), The stage (drama), Essays and the novel (prose), Criticism, terms and ideas (terms).

## `restoration` — Restoration Age (1660–1700)

Notes: `/notes/restoration-age/` (Restoration — the full notes). `age` = `restoration`, `ageName` = `Restoration Age`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Charles II, the reopened theatres, Dryden, Congreve, Aphra Behn, Milton, Bunyan and Pepys |
| 2 | Restoration comedy and tragedy | easy + medium | planned | The Man of Mode, The Country Wife, The Way of the World, The Rover, The Relapse, Venice Preserv'd, All for Love |
| 3 | Dryden, Milton and Restoration poetry | medium + hard | planned | Absalom and Achitophel, MacFlecknoe, Paradise Lost, Hudibras, Rochester's A Satyr against Mankind |
| 4 | Prose, diaries and ideas | medium + hard | planned | The Pilgrim's Progress, Pepys's Diary, Evelyn, Locke's Essay Concerning Human Understanding, Oroonoko, Rymer and Collier |

Hub topics the plan uses: The age, the king and the theatres (ground), Comedy and tragedy (drama), Poetry and satire (poetry), Prose, diaries and ideas (prose), Terms, dates and sources (terms).

## `augustan-age` — Augustan Age (1700–1745)

Notes: `/notes/augustan-age/` (Augustan Age — the full notes). `age` = `augustan-age`, `ageName` = `Augustan Age`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Pope, Swift, Defoe, Addison and Steele, Gay, Farquhar, Rowe, Anne Finch, Berkeley and Hume |
| 2 | Pope and Augustan verse | easy + medium | planned | An Essay on Criticism, The Rape of the Lock, The Dunciad, An Essay on Man, Gay's Trivia, Anne Finch, Isaac Watts |
| 3 | Swift, Defoe and the periodical essay | medium + hard | planned | Gulliver's Travels, A Modest Proposal, Robinson Crusoe, Moll Flanders, The Tatler, The Spectator |
| 4 | The stage, ideas and women writers | medium + hard | planned | The Beggar's Opera, Farquhar, Rowe, Berkeley, Hume, Lady Mary Wortley Montagu, Anne Finch |

Hub topics the plan uses: The age and its ideas (ground), Pope and Augustan verse (poetry), Swift, Defoe and the periodical essay (prose), The stage, ideas and women writers (stage), Terms, dates and sources (terms).

## `age-of-sensibility` — Age of Sensibility (1745–1785)

Notes: `/notes/augustan-age/` (Augustan Age — the full notes). `age` = `age-of-sensibility`, `ageName` = `Age of Sensibility`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Johnson, Goldsmith, Sheridan, Richardson, Fielding, Sterne, Gray, Cowper, Gibbon and Burke |
| 2 | The novel: Richardson, Fielding, Smollett and Sterne | easy + medium | planned | Clarissa, Tom Jones, Roderick Random, Humphry Clinker, Tristram Shandy, Walpole's The Castle of Otranto, Mackenzie |
| 3 | Poetry: Gray, Collins, Smart, Cowper and Crabbe | medium + hard | planned | Gray's Elegy, Collins, Smart, Cowper's The Task, Crabbe, Goldsmith's The Deserted Village |
| 4 | Johnson, the stage and the prose of ideas | medium + hard | planned | Johnson's Dictionary and Lives of the Poets, Boswell, She Stoops to Conquer, The School for Scandal, Gibbon, Adam Smith, Burke |

Hub topics the plan uses: The age and its tastes (ground), The novel (novel), Poetry (poetry), Johnson, the stage and ideas (johnson), Terms, dates and sources (terms).

## `romantic-age` — Romantic Period (1785–1832)

Notes: `/notes/romantic-age/` (Romantic Age — the full notes). `age` = `romantic-age`, `ageName` = `Romantic Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Burns, Blake, Wordsworth, Coleridge, Byron, Shelley, Keats, Austen, Scott, Mary Shelley, Lamb and Hazlitt |
| 2 | Blake, Wordsworth and Coleridge | easy + medium | planned | Songs of Innocence and of Experience, Lyrical Ballads, The Prelude, The Rime of the Ancient Mariner, Kubla Khan, Biographia Literaria |
| 3 | Byron, Shelley, Keats and Clare | medium + hard | planned | Don Juan, Prometheus Unbound, Adonais, A Defence of Poetry, Keats's odes, The Eve of St Agnes, John Clare |
| 4 | The novel: Austen, Scott, Mary Shelley and the Gothic | medium + hard | planned | Pride and Prejudice, Emma, Waverley, Ivanhoe, Frankenstein, the Gothic novel |
| 5 | Essays, ideas and criticism | medium + hard | planned | Burke, Paine, Wollstonecraft, Godwin, Lamb's Essays of Elia, Hazlitt's The Spirit of the Age, De Quincey's Confessions, Peacock's The Four Ages of Poetry |

Hub topics the plan uses: The age and its revolutions (ground), Blake, Wordsworth and Coleridge (first), Byron, Shelley, Keats and Clare (second), The novel and the Gothic (novel), Essays, ideas and criticism (prose), Terms, dates and sources (terms).

## `victorian-age` — Victorian Period (1832–1901)

Notes: `/notes/victorian-age/` (Victorian Age — the full notes). `age` = `victorian-age`, `ageName` = `Victorian Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Dickens, Thackeray, the Brontës, George Eliot, Hardy, Tennyson, Browning, Arnold, Carlyle, Ruskin and Wilde |
| 2 | The Victorian novel: Dickens to Hardy | easy + medium | planned | Great Expectations, Vanity Fair, Jane Eyre, Wuthering Heights, Middlemarch, Tess of the d'Urbervilles, Gaskell, Trollope |
| 3 | Victorian poetry: Tennyson to Hopkins | medium + hard | planned | In Memoriam, Idylls of the King, The Ring and the Book, 'Dover Beach', Rossetti, Swinburne, Hopkins, FitzGerald's Rubaiyat |
| 4 | Prose, ideas and criticism | medium + hard | planned | Carlyle's Sartor Resartus, Mill's On Liberty, Ruskin, Newman's Apologia, Darwin's On the Origin of Species, Arnold's Culture and Anarchy, Pater's The Renaissance |
| 5 | The late Victorians: fiction, drama and the fin de siècle | medium + hard | planned | Dr Jekyll and Mr Hyde, The Time Machine, Dracula, Kipling, The Importance of Being Earnest, Pinero, aestheticism |

Hub topics the plan uses: The age and its society (ground), The novel (novel), Poetry (poetry), Essays, ideas and criticism (prose), The late Victorians and the fin de siècle (late), Terms, dates and sources (terms).

## `edwardian` — Edwardian Period (1901–1914)

Notes: `/notes/modern-age/` (Modern — the full notes). `age` = `edwardian`, `ageName` = `Edwardian Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Shaw, Galsworthy, Bennett, Wells, Conrad, Forster, Yeats, Hardy, Synge and the Abbey Theatre |
| 2 | The novel: Conrad, Forster, Wells, Bennett and Galsworthy | easy + medium | planned | Nostromo, The Secret Agent, Howards End, Tono-Bungay, The Old Wives' Tale, The Man of Property, Henry James |
| 3 | Drama and the Abbey Theatre | medium + hard | planned | Shaw's Man and Superman, Synge's Riders to the Sea and The Playboy of the Western World, Barrie's Peter Pan, Yeats, Lady Gregory |
| 4 | Poetry, new movements and the Bloomsbury Group | medium + hard | planned | Yeats, Hardy's The Dynasts, the Georgian poets, the Imagists, Pound's Ripostes, Kipling, Chesterton, the Bloomsbury Group |

Hub topics the plan uses: The age and its society (ground), The novel (novel), Drama and the Abbey Theatre (drama), Poetry and new movements (poetry), Terms, dates and sources (terms).

## `georgian` — Georgian Period (1910–1936)

Notes: `/notes/modern-age/` (Modern — the full notes). `age` = `georgian`, `ageName` = `Georgian Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Georgian Poetry, Brooke, the war poets, Lawrence, Woolf, Joyce, Eliot, Yeats, Huxley and Auden |
| 2 | Georgian poets and the war poets | easy + medium | planned | Georgian Poetry, the Dymock poets, Brooke, Masefield, Owen, Sassoon, Rosenberg, Sorley, Gurney, Blunden |
| 3 | The novel: Lawrence, Woolf, Joyce, Ford and Forster | medium + hard | planned | Sons and Lovers, Ulysses, Mrs Dalloway, To the Lighthouse, The Good Soldier, A Passage to India, Huxley's Brave New World |
| 4 | Eliot, Yeats, Auden and the stage | medium + hard | planned | The Waste Land, Yeats's The Tower, Auden, Shaw's Saint Joan, Orwell, Waugh's Decline and Fall |

Hub topics the plan uses: The age and its movements (ground), Georgian poetry and the war poets (poetry), The novel (novel), Eliot, Yeats, Auden and the stage (later), Terms, dates and sources (terms).

## `modern` — Modern Period (1914–1945)

Notes: `/notes/modern-age/` (Modern — the full notes). `age` = `modern`, `ageName` = `Modern Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | the war poets, Yeats, Eliot, Joyce, Woolf, Lawrence, Auden, Orwell, Greene, Shaw and the critics Richards, Empson and Leavis |
| 2 | Poetry: the war poets, Yeats and Eliot | easy + medium | planned | Owen, Sassoon, Rosenberg, David Jones, Yeats's The Tower, Eliot's The Waste Land and Four Quartets, Pound's The Cantos |
| 3 | The novel: Joyce, Woolf, Lawrence and Forster | medium + hard | planned | Ulysses, Mrs Dalloway, Women in Love, A Passage to India, Parade's End, Mansfield's The Garden Party |
| 4 | The 1930s and 1940s: Auden, Orwell, Waugh and Greene | medium + hard | planned | Auden, Animal Farm, Waugh's A Handful of Dust, Greene's Brighton Rock, Huxley's Brave New World, MacNeice, Dylan Thomas |
| 5 | Drama, criticism and terms | medium + hard | planned | Shaw, O'Casey's Juno and the Paycock, Coward, Bradley, Richards's Practical Criticism, Empson, Leavis, modernism, stream of consciousness, the objective correlative |

Hub topics the plan uses: The age and its movements (ground), War poets, Yeats and Eliot (poetry), The novel (novel), The 1930s and 1940s (thirties), Drama and criticism (drama), Terms, dates and sources (terms).

## `postmodern` — Postmodern Period (1945–present)

Notes: `/notes/contemporary-age/` (Contemporary — the full notes). `age` = `postmodern`, `ageName` = `Postmodern Period`.

| Set | Title (`setName`) | Levels | Status | Scope |
|---|---|---|---|---|
| 1 | Across the whole age | easy + medium | planned | Orwell, Golding, Beckett, Pinter, Larkin, Hughes, Heaney, Rushdie and Achebe |
| 2 | The novel from Orwell to Mantel | easy + medium | planned | Nineteen Eighty-Four, Lord of the Flies, The Golden Notebook, The French Lieutenant's Woman, The Bloody Chamber, The Remains of the Day, Wolf Hall |
| 3 | Drama: Beckett, Pinter, Osborne, Stoppard and Friel | medium + hard | planned | Waiting for Godot, Look Back in Anger, The Birthday Party, Rosencrantz and Guildenstern Are Dead, Friel, Churchill's Top Girls |
| 4 | Poetry: Larkin, Hughes, Heaney and Walcott | medium + hard | planned | The Whitsun Weddings, The Hawk in the Rain, Death of a Naturalist, North, Omeros, the Movement |
| 5 | Postcolonial writing and critical ideas | medium + hard | planned | Things Fall Apart, A House for Mr Biswas, Midnight's Children, The God of Small Things, Coetzee, Said's Orientalism, poststructuralism |

Hub topics the plan uses: The age and its movements (ground), The novel (novel), Drama (drama), Poetry (poetry), Postcolonial writing and criticism (postcolonial), Terms and criticism (terms).

