# The 20 ages of the site

Generated from `_data/mcqSpec.json` and the validator. **Copy these values exactly** into a set file.

| `age` (hub slug) | `ageName` | Years | `notes` | `notesTitle` | `periodId` values used by this age |
|---|---|---|---|---|---|
| `old-english` | Old English | 450–1066 | `/notes/old-english/` | Old English — the full notes | `anglo-saxon` |
| `anglo-norman` | Anglo-Norman Period | 1066–1340 | `/notes/middle-english/` | Middle English — the full notes | `anglo-norman` |
| `age-of-chaucer` | Age of Chaucer | 1340–1400 | `/notes/middle-english/` | Middle English — the full notes | `age-of-chaucer` |
| `fifteenth-century` | Fifteenth Century | 1400–1500 | `/notes/middle-english/` | Middle English — the full notes | `fifteenth-century` |
| `renaissance` | Renaissance Period | 1500–1660 | `/notes/renaissance/` | Renaissance — the full notes | `caroline`, `commonwealth`, `early-tudor`, `elizabethan`, `jacobean-era` |
| `early-tudor` | Early Tudor Period | 1500–1558 | `/notes/renaissance/` | Renaissance — the full notes | `early-tudor` |
| `elizabethan` | Elizabethan Age | 1558–1603 | `/notes/renaissance/` | Renaissance — the full notes | `elizabethan` |
| `jacobean` | Jacobean Age | 1603–1625 | `/notes/jacobean-and-caroline-age/` | Jacobean and Caroline — the full notes | `jacobean-era` |
| `caroline` | Caroline Age | 1625–1649 | `/notes/jacobean-and-caroline-age/` | Jacobean and Caroline — the full notes | `caroline` |
| `commonwealth` | Commonwealth Period | 1649–1660 | `/notes/jacobean-and-caroline-age/` | Jacobean and Caroline — the full notes | `commonwealth` |
| `neoclassical` | Neoclassical Period | 1660–1785 | `/notes/restoration-age/` | Restoration — the full notes | `age-of-sensibility`, `augustan`, `restoration-era` |
| `restoration` | Restoration Age | 1660–1700 | `/notes/restoration-age/` | Restoration — the full notes | `restoration-era` |
| `augustan-age` | Augustan Age | 1700–1745 | `/notes/augustan-age/` | Augustan Age — the full notes | `augustan` |
| `age-of-sensibility` | Age of Sensibility | 1745–1785 | `/notes/augustan-age/` | Augustan Age — the full notes | `age-of-sensibility` |
| `romantic-age` | Romantic Period | 1785–1832 | `/notes/romantic-age/` | Romantic Age — the full notes | `romantic` |
| `victorian-age` | Victorian Period | 1832–1901 | `/notes/victorian-age/` | Victorian Age — the full notes | `victorian` |
| `edwardian` | Edwardian Period | 1901–1914 | `/notes/modern-age/` | Modern — the full notes | `edwardian` |
| `georgian` | Georgian Period | 1910–1936 | `/notes/modern-age/` | Modern — the full notes | `georgian` |
| `modern` | Modern Period | 1914–1945 | `/notes/modern-age/` | Modern — the full notes | `modern-era` |
| `postmodern` | Postmodern Period | 1945–present | `/notes/contemporary-age/` | Contemporary — the full notes | `postmodern` |

`renaissance` and `neoclassical` span several periods. Place each question by the rules in SKILL.md section 5. A period outside the list above is allowed only when textbook placement says so.
